/*Verificare che i campi definiti come PK siano univoci. In altre parole, scrivi una query per determinare l’univocità dei valori di ciascuna PK (una query per tabella implementata)/*
SELECT CATEGORY_ID, COUNT(*)
FROM CATEGORY
GROUP BY CATEGORY_ID
HAVING COUNT(*)> 1 
;
SELECT PRODUCT_ID, COUNT(*)
FROM PRODUCT
GROUP BY PRODUCT_ID
HAVING COUNT(*)> 1 
;
SELECT REGION_ID, COUNT(*)
FROM REGION
GROUP BY REGION_ID
HAVING COUNT(*)> 1 
;

SELECT STATES_ID, COUNT(*)
FROM STATES
GROUP BY STATES_ID
HAVING COUNT(*)> 1 
;
SELECT SALES_ID, COUNT(*)
FROM SALES
GROUP BY SALES_ID
HAVING COUNT(*)> 1 
;
/*Esporre l’elenco delle transazioni indicando nel result set 
il codice documento, la data, il nome del prodotto, la categoria del prodotto, il nome dello stato, il nome della regione di vendita e 
un campo booleano valorizzato in base alla condizione 
che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)/*
SELECT
t.product_id AS Codice_Documento
, t.sales_data AS Data_Documento
, p.product_name AS Nome_Prodotto
, c.category_name AS Categoria_Prodotto
, s.States_name AS Nome_Stato_Vendita
, r.region_name AS Nome_Regione_Vendita
, case
when datediff(curdate(),
t.sales_data)>180 then true else false end as oltre_180_giorni
from
sales t
join
product p on t.product_id=p.product_id
join 
category c on p.category_id=c.category_id
join
states s on t.states_id=s.states_id
join
region r on t.region_id= r.region_id
;
/Esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle vendite realizzate nell’ultimo anno censito. 
(ogni valore della condizione deve risultare da una query e non deve essere inserito a mano). 
Nel result set devono comparire solo il codice prodotto e il totale venduto/*
SELECT
v.product_id
, SUM(v.quantity) AS Totale_Venduto
from
sales v
WHERE
YEAR (v.sales_data)=(
select MAX(year(sales_data))
from
sales
)
group by
v. product_id
having
SUM(v.quantity) > (
select AVG (v2.totale_prodotto)
from (
select
product_id
, SUM(quantity) AS Totale_prodotto
from sales
where year (sales_data)=(
select
MAX(year(sales_data))
from sales
)
group by
product_id) AS v2
);
/Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente./*
SELECT
s.States_name AS STATO
, r.Region_name AS Regione
, YEAR(sa.Sales_data) AS Anno
, SUM(sa.Unit_price * sa.Quantity) AS Fatturato_totale
FROM 
Sales sa 
JOIN
States s ON sa.States_Id = s.States_Id
join
Region r ON s.Region_Id = r.Region_Id
GROUP BY
STATO, Regione,Anno
ORDER BY
Anno ASC
, Fatturato_totale DESC
;
/Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?/*
SELECT
c.category_name
, SUM(v.Quantity) AS  Totale_richiesto
FROM
Sales v
JOIN
Product p ON v.Product_Id=p.Product_Id
JOIN
Category c ON p.Category_Id=c.Category_Id
GROUP BY
C.Category_name
ORDER BY
Totale_richiesto desc
;
/*Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” delle informazioni
 utili (codice prodotto, nome prodotto, nome categoria)/*
 
 CREATE VIEW
vista_prodotti_denormalizzata AS SELECT
p.Product_Id AS Codice_Prodotto
, P.Product_name
, c.Category_name
FROM
product AS p
JOIN
category AS c ON p. Category_Id=c.Category_Id
;
select *
 from
 Vista_prodotti_denormalizzata
 ;
 /*Creare una vista per le informazioni geografiche/*
 CREATE VIEW
 Vista_Informazioni_Geografiche AS SELECT
 s.States_Id AS Stato_id
 , s.States_name AS Nome_stato
 , r.Region_Id AS Regione_Id
 FROM
 States s
 JOIN
 Region r ON s.Region_Id = r.Region_Id
 ;
 select *
 from
 Vista_informazioni_geografiche
 ;