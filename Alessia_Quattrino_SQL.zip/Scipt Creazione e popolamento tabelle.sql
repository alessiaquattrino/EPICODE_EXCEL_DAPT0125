-- CREAZIONE DATABASE
CREATE DATABASE TOYS;
USE TOYS;
-- CREAZIONE TABELLA CATEGORY
CREATE TABLE CATEGORY (
CATEGORY_ID VARCHAR (25)
, CATEGORY_NAME VARCHAR (100)
, CATEGORY_DESCRIPTION VARCHAR (255)
, CONSTRAINT PK_CATEGORY PRIMARY KEY (CATEGORY_ID)
);
-- CREAZIONE TABELLA PRODUCT
CREATE TABLE PRODUCT (
PRODUCT_ID VARCHAR (25)
, PRODUCT_NAME VARCHAR (100)
, UNIT_PRICE DECIMAL (10,2)
, CATEGORY_ID VARCHAR (25)
, CONSTRAINT PK_PRODUCT PRIMARY KEY (PRODUCT_ID)
, CONSTRAINT FK_CATEGORY_PRODUCT FOREIGN KEY (CATEGORY_ID) REFERENCES CATEGORY (CATEGORY_ID)
);
-- CREAZIONE DELLA TABELLA REGION

CREATE TABLE REGION (
region_id int
, region_name varchar (100)
, constraint PK_REGION PRIMARY KEY (REGION_ID)
);


-- CREAZIONE TABELLA STATES
CREATE TABLE STATES (
STATES_ID VARCHAR (25)
, STATES_NAME VARCHAR (100)
, REGION_ID INT
, CONSTRAINT PK_STATES PRIMARY KEY (STATES_ID)
, CONSTRAINT FK_REGION_STATES FOREIGN KEY(REGION_ID) REFERENCES REGION (REGION_ID)
);
-- CREAZIONE TABELLA SALES
CREATE TABLE SALES (
SALES_ID VARCHAR (25)
, SALES_DATA date
, REGION_ID int
, STATES_ID VARCHAR (25)
, PRODUCT_ID VARCHAR (25)
, UNIT_PRICE DECIMAL (10,2)
, QUANTITY int
, CONSTRAINT PK_SALES PRIMARY KEY (SALES_ID)
, CONSTRAINT FK_PRODUCT_SALES FOREIGN KEY (PRODUCT_ID) REFERENCES PRODUCT (PRODUCT_ID)
, CONSTRAINT FK_REGION_SALES FOREIGN KEY (REGION_ID) REFERENCES REGION (REGION_ID)
, CONSTRAINT FK_STATES_SALES FOREIGN KEY (STATES_ID) REFERENCES STATES (STATES_ID)
);
-- POPOLAMENTO TABELLA CATEGORY
INSERT INTO CATEGORY  VALUES
("CAT001","Peluche","comprende giocattoli realizzati con materiali morbidi e imbottiti,
 offrono confort e compagnia ai bambini")
, ("CAT002","giochi da tavolo","include giochi che richiedono la partecipazione di più giocatori, 
promuovono l'interazione sociale, il pensiero strategico,la logica, la memoria e la collaborazione")
, ("CAT003","costruzioni","comprende set e singoli componenti progettati per essere assemblati. 
Sviluppano la creatività, il pensiero spaziale, la coordinazione occhio-mano e la capacità di risoluzione dei problemi.")
, ("CAT004","puzzle","comprende giochi che consistono nell'assemblare pezzi interconnessi per formare un'immagine. 
Sviluppano il ragionamento logico, la pazienza e la capacità di problem solving")
, ("CAT005","giochi telecomandati","comprende giocattoli che possono essere controllati a distanza tramite un dispositivo. 
Stimolano la coordinazione occhio-mano, la consapevolezza spaziale e
 offrono un'espperienza di gioco dinamica e interattiva")
, ("CAT006","bambole","include giocattoli che rappresentano figure umane spesso accessoriate.
 Stimolano l'immaginazione, l'espressione emotiva e la capacità narrativa dei bambini.")
 ;

-- POPOLAMENTO TABELLA PRODUCT
INSERT INTO PRODUCT VALUES
("PROD-0001","Orsetto di peluche",30.00,"CAT001")
, ("PROD-0002","Coniglietto di peluche",20.00,"CAT001")
, ("PROD-0003","gattino di peluche",25.00,"CAT001")
, ("PROD-0004","monopoly",40.00, "CAT002")
, ("PROD-0005","azul",35.00,"CAT002")
, ("PROD-0006","labirinto",30.00,"CAT002")
, ("PROD-0007","battaglia navale",15.00,"CAT002")
, ("PROD-0008","dixie",50.00,"CAT002")
, ("PROD-0009","cluedo",55.00,"CAT002")
, ("PROD-0010","lego friends",120.00,"CAT003")
, ("PROD-0011","lego city","130.00","CAT003")
, ("PROD-0012","lego technic","150.00","CAT003")
, ("PROD-0013","puzzle 100 pezzi",12.00,"CAT004")
, ("PROD-0014","puzzle 500 pezzi",15.00,"CAT004")
, ("PROD-0015","macchina telecomandata",60.00,"CAT005")
, ("PROD-0016","drone telecomandato",170.00, "CAT005")
, ("PROD-0017","barbie",32.00,"CAT006")
, ("PROD-0018","ken",31.00 ,"CAT006")
;
-- POPOLAMENTO TABELLA REGION
INSERT INTO REGION VALUES
(101,"Europa Occidentale")
, (102,"Europa Orientale")
, (103,"Nord America")
, (104,"Sud America")
, (105,"Asia Orientale")
, (106,"Oceania")
;

-- POPOLAMENTO TABELLA STATES
INSERT INTO STATES VALUES
("A1","Francia",101)
, ("A2","Germania",101)
, ("A3","Regno Unito",101)
, ("A4","Spagna",101)
, ("A5","Italia",101)
, ("B1","Polonia",102)
, ("B2","Ungheria",102)
, ("B3","Romania",102)
, ("B4","Bulgaria",102)
, ("C1","Stati Uniti",103)
, ("C2","Canada",103)
, ("C3","Messico",103)
, ("D1","Brasile",104)
, ("D2","Argentina",104)
, ("D3","Colombia",104)
, ("D4","Perù",104)
, ("E1","Cina",105)
, ("E2","Giappone",105)
, ("F1","Australia",106)
, ("F2","Nuova Zelanda",106)
;
-- POPOLAMENTO TABELLA SALES
INSERT INTO SALES VALUES
('SOH -12345-001','2025-04-12',101,'A1','PROD-0001',30.00 ,20)
, ('SOH -12345-002','2025-04-13',101,'A1','PROD-0007',15.00,20)
, ('SOH -12345-003','2025-04-14',101,'A5','PROD-0003',25.00,10)
, ('SOH -12345-004','2025-04-15',103,'C1','PROD-0018', 31.00,20)
, ('SOH -12345-005','2025-04-16',103,'C1','PROD-0012', 150.00,20)
, ('SOH -12345-006','2025-04-17',103,'C3','PROD-0001', 30.00,20 )
, ('SOH -12345-007','2025-04-18',105,'E2','PROD-0018', 31.00, 20 )
, ('SOH -12345-008','2025-04-19',105,'E2','PROD-0012', 31.00,20)
, ('SOH -12345-010','2025-04-21',104,'D2','PROD-0011', 130.00,10)
, ('SOH -12345-011','2025-04-22',101,'A4','PROD-0003', 25.00,10)
, ('SOH -12345-012','2025-04-23',103,'C1','PROD-0018', 31.00, 20)
, ('SOH -12345-013','2025-04-24',104, 'D2','PROD-0004', 40.00, 10)
, ('SOH -12345-014','2025-04-25',101, 'A5','PROD-0001', 30.00 ,30)
, ('SOH -12345-015','2025-04-27',101,'A1','PROD-0012', 150.00 ,20)
, ('SOH -12345-017','2025-04-28',104,'D2','PROD-0004', 40.00 ,20 )
, ('SOH -12345-018','2025-04-29',101,'A5','PROD-0001',30.00, 20 )
, ('SOH -12345-019','2025-04-30',101,'A4','PROD-0007',15.00, 30 )
, ('SOH -12345-020','2025-05-01',103,'C1','PROD-0018',31.00, 30 )
, ('SOH -12345-021','2025-05-02',101,'A5','PROD-0001',30.00, 30 )
;

